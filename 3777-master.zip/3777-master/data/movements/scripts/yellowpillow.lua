function onStepIn(cid, item, position, lastPosition, fromPosition, toPosition, actor)
	doSendAnimatedText(position, "Faaart!", 192)
	return true
end